package dao;

import daolmpl.SellTicketDAOlmpl;

public class DAOFactory {
	public static SellTicketDAO getSellTicketDAO(){
        return new SellTicketDAOlmpl() ;
}
}
